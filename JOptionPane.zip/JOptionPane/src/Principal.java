import javax.swing.JOptionPane;
public class Principal {
    public static void main(String[] args) {
        String nome = JOptionPane.showInputDialog(null, "Qual o seu nome", "Identificação de Usuário", JOptionPane.QUESTION_MESSAGE);
              
        String txt = JOptionPane.showInputDialog(null, "Qual a sua idade?", "Questionário", JOptionPane.QUESTION_MESSAGE);
        int idade = Integer.parseInt(txt);
        
        if (idade >= 18){
            JOptionPane.showMessageDialog(null,nome+","+" você já pode tirar a CNH.");
        }else{
            JOptionPane.showMessageDialog(null, nome+","+" você ainda não pode tirar a CNH, você tem apenas "+idade+" anos");
    }
     
    }
}
    